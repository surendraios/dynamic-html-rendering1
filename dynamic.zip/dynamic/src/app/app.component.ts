import { Component, inject, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  unsubcribe: any;
  myItems
  name = 'Ngx-Dynamic-Compiler';
  template = `
  <ul>
  <li> <h2> String Interpolation Result  </h2> - {{Data.Result}}
				<h2>*ngFor Example</h2></li>
  <li>	<ol>
				<li *ngFor="let r of Data.ArraySample">{{r}}</li>
				</ol></li>
  </ul>
 
      `;
  htmlRender : SafeHtml;

   bindData = {
    Result: 'Hola !, Coffee ?',
    ArraySample: ['Tea', 'Green Tea']
  }
  bindData2 = {
    'Brand': {
      html: `<select class="form-control" id="field.name" formControlName="field.name">
   <option *ngFor="let opt of field.options" value="opt.key">{{opt.label}}</option>
 </select>`, field: {
        type: 'dropdown',
        name: 'Brand',
        label: 'Brand',
        value: 'company2',
        required: true,
        options: [
          { key: 'company1', label: 'Company1' },
          { key: 'company2', label: 'Company2' },
          { key: 'company3', label: 'Company3' },
          { key: 'company4', label: 'Company4' }
        ]
      }
    }, 'ContactNumber': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'ContactNumber',
        label: 'Contact Number',
        value: '8747737343',
        required: true
      }
    },
    'ContactTel1': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'ContactTel1',
        label: 'Contact Tel1',
        value: '',
        required: true
      }
    },
    'ContactTel2': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'ContactTel2',
        label: 'Contact Tel2',
        value: '',
        required: true
      }
    },
    'DateEntry': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'date',
        name: 'DzteEntry',
        label: 'Date Entry',
        value: '2020-02-15',
        required: true
      }
    },
    'Datenotify': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'date',
        name: 'Datenotify',
        label: 'Date Notify',
        value: '2020-02-15',
        required: true
      }
    },
    'DescriptionIncident': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'DescriptionIncident',
        label: 'Description Incident',
        value: '',
        required: true
      }
    },
    'FullName': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'FullName',
        label: 'Full Name',
        value: '',
        required: true
      }
    },
    'InjurdTimeHr': {
      html: `<select class="form-control" id="field.name" formControlName="field.name">
<option *ngFor="let opt of field.options" value="opt.key">{{opt.label}}</option>
</select>`, field: {
        type: 'dropdown',
        name: 'InjurdTimeHr',
        label: 'InjurdTimeHr',
        value: '02',
        required: true,
        options: [
          { key: '01', label: '01' },
          { key: '02', label: '02' },
          { key: '03', label: '03' },
          { key: '04', label: '04' },
          { key: '05', label: '05' },
          { key: '06', label: '06' },
          { key: '07', label: '07' },
          { key: '08', label: '08' },
          { key: '09', label: '09' },
          { key: '10', label: '10' },
          { key: '11', label: '11' },
          { key: '12', label: '12' }
        ]
      }
    },
    'InjurdTimeMnt': {
      html: `<select class="form-control" id="field.name" formControlName="field.name">
<option *ngFor="let opt of field.options" value="opt.key">{{opt.label}}</option>
</select>`, field: {
        type: 'dropdown',
        name: 'InjurdTimeMnt',
        label: 'InjurdTimeMnt',
        value: '25',
        required: true,
        options: [
          { key: '01', label: '01' },
          { key: '02', label: '02' },
          { key: '03', label: '03' },
          { key: '04', label: '04' },
          { key: '05', label: '05' },
          { key: '06', label: '06' },
          { key: '07', label: '07' },
          { key: '08', label: '08' },
          { key: '09', label: '09' },
          { key: '10', label: '10' },
          { key: '11', label: '11' },
          { key: '12', label: '12' },
          { key: '13', label: '13' },
          { key: '14', label: '14' },
          { key: '15', label: '15' },
          { key: '16', label: '16' },
          { key: '17', label: '17' },
          { key: '18', label: '18' },
          { key: '19', label: '19' },
          { key: '20', label: '20' },
          { key: '21', label: '21' },
          { key: '22', label: '22' },
          { key: '23', label: '23' },
          { key: '24', label: '24' },
          { key: '25', label: '25' },
          { key: '26', label: '26' },
          { key: '27', label: '27' },
          { key: '28', label: '28' },
          { key: '29', label: '29' },
          { key: '30', label: '30' },
          { key: '31', label: '31' },
          { key: '32', label: '32' },
          { key: '33', label: '33' },
          { key: '34', label: '34' },
          { key: '35', label: '35' },
          { key: '36', label: '36' },
          { key: '37', label: '37' },
          { key: '38', label: '38' },
          { key: '39', label: '39' },
          { key: '40', label: '40' },
          { key: '41', label: '41' },
          { key: '42', label: '42' },
          { key: '43', label: '43' },
          { key: '44', label: '44' },
          { key: '45', label: '45' },
          { key: '46', label: '46' },
          { key: '47', label: '47' },
          { key: '48', label: '48' },
          { key: '49', label: '49' },
          { key: '50', label: '50' },
          { key: '51', label: '51' },
          { key: '52', label: '52' },
          { key: '53', label: '53' },
          { key: '54', label: '54' },
          { key: '55', label: '55' },
          { key: '56', label: '56' },
          { key: '57', label: '57' },
          { key: '58', label: '58' },
          { key: '59', label: '59' },
          { key: '00', label: '00' }
        ]
      }
    },
    'ManagerName': {
      html: `<select class="form-control" id="field.name" formControlName="field.name">
<option *ngFor="let opt of field.options" value="opt.key">{{opt.label}}</option>
</select>`, field: {
        type: 'dropdown',
        name: 'ManagerName',
        label: 'Manager Name',
        value: 'jack',
        required: true,
        options: [
          { key: 'ram', label: 'Ram' },
          { key: 'shyam', label: 'Shyam' },
          { key: 'jack', label: 'jack' }
        ]
      }
    },
    'Name1': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'Name1',
        label: 'Name1',
        value: '',
        required: true
      }
    },
    'Name2': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'Name2',
        label: 'Name2',
        value: '',
        required: true
      }
    },
    'NotifyManager': {
      html: `<div class="form-check" *ngFor="let opt of field.options">
<input formControlName="field.name" class="form-check-input" type="radio" value="opt.key" >
<label class="form-check-label">
  {{opt.label}}
</label>
</div>`, field: {
        type: 'radio',
        name: 'NotifyManager',
        label: 'Notify Manager',
        value: 'n',
        required: true,
        options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
      }
    },
    'OtherDetail': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'OtherDetail',
        label: 'Other Detail',
        value: '',
        required: true
      }
    },
    'PartofBody': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'PartofBody',
        label: 'Part of Body',
        value: '',
        required: true
      }
    },
    'PositionTitle': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'PositionTitle',
        label: 'Position Title',
        value: '',
        required: true
      }
    },
    'ReturntoWork': {
      html: `<div class="form-check" *ngFor="let opt of field.options">
<input formControlName="field.name" class="form-check-input" type="radio" value="opt.key" >
<label class="form-check-label">
  {{opt.label}}
</label>
</div>`, field: {
        type: 'radio',
        name: 'ReturntoWork',
        label: 'Return to Work',
        value: 'n',
        required: true,
        options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
      }
    },
    'TimeAP': {
      html: `<select class="form-control" id="field.name" formControlName="field.name">
<option *ngFor="let opt of field.options" value="opt.key">{{opt.label}}</option>
</select>`, field: {
        type: 'dropdown',
        name: 'TimeAP',
        label: 'Time AP',
        value: 'am',
        required: true,
        options: [{ key: 'am', label: 'AM' }, { key: 'pm', label: 'PM' }]
      }
    },
    'Treatment': {
      html: `<div [formGroup]="field.name" >
<div *ngFor="let opt of field.options" class="form-check form-check">
<label class="form-check-label">
   <input [formControlName]="opt.key" class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" />
   {{opt.label}}</label>
</div>
</div>`, field: {
        type: 'checkbox',
        name: 'Treatment',
        label: 'Treatment',
        required: true,
        options: [
          { key: 'treatment1', label: 'Treatment1' },
          { key: 'treatment2', label: 'Treatment2' },
          { key: 'treatment3', label: 'Treatment3' },
          { key: 'treatment4', label: 'Treatment4' },
          { key: 'treatment5', label: 'Treatment5' }
        ]
      }
    },
    'WhereIncident': {
      html: `<input  attr.type="field.type" class="form-control"  id="field.name" name="field.name" formControlName="field.name">
<textarea *ngIf="field.multiline" [class.is-invalid]="isDirty && !isValid" formControlName="field.name" id="field.name"
rows="9" class="form-control" [placeholder]="field.placeholder"></textarea>`, field: {
        type: 'text',
        name: 'WhereIncident',
        label: 'Where Incident',
        value: '',
        required: true
      }
    },
    'Witnesses': {
      html: `<div class="form-check" *ngFor="let opt of field.options">
<input formControlName="field.name" class="form-check-input" type="radio" value="opt.key" >
<label class="form-check-label">
  {{opt.label}}
</label>
</div>`, field: {
        type: 'radio',
        name: 'Witnesses',
        label: 'Witnesses',
        value: 'n',
        required: true,
        options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
      }
    }

  }
  form: FormGroup;


  fields: any[] = [
    {
      type: 'dropdown',
      name: 'brand',
      label: 'Brand',
      value: 'company2',
      required: true,
      options: [
        { key: 'company1', label: 'Company1' },
        { key: 'company2', label: 'Company2' },
        { key: 'company3', label: 'Company3' },
        { key: 'company4', label: 'Company4' }
      ]
    },
    {
      type: 'text',
      name: 'contactNumber',
      label: 'Contact Number',
      value: '8747737343',
      required: true
    },
    {
      type: 'text',
      name: 'ContactTel1',
      label: 'Contact Tel1',
      value: '',
      required: true
    },

    {
      type: 'text',
      name: 'ContactTel2',
      label: 'Contact Tel2',
      value: '',
      required: true
    },
    {
      type: 'date',
      name: 'dateEntry',
      label: 'Date Entry',
      value: '2020-02-15',
      required: true
    },
    {
      type: 'date',
      name: 'datenotify',
      label: 'Date Notify',
      value: '2020-02-15',
      required: true
    },
    {
      type: 'text',
      name: 'DescriptionIncident',
      label: 'Description Incident',
      value: '',
      required: true
    },

    {
      type: 'text',
      name: 'FullName',
      label: 'Full Name',
      value: '',
      required: true
    },
    {
      type: 'dropdown',
      name: 'injurdTimeHr',
      label: 'InjurdTimeHr',
      value: '02',
      required: true,
      options: [
        { key: '01', label: '01' },
        { key: '02', label: '02' },
        { key: '03', label: '03' },
        { key: '04', label: '04' },
        { key: '05', label: '05' },
        { key: '06', label: '06' },
        { key: '07', label: '07' },
        { key: '08', label: '08' },
        { key: '09', label: '09' },
        { key: '10', label: '10' },
        { key: '11', label: '11' },
        { key: '12', label: '12' }
      ]
    },
    {
      type: 'dropdown',
      name: 'injurdTimeMnt',
      label: 'InjurdTimeMnt',
      value: '25',
      required: true,
      options: [
        { key: '01', label: '01' },
        { key: '02', label: '02' },
        { key: '03', label: '03' },
        { key: '04', label: '04' },
        { key: '05', label: '05' },
        { key: '06', label: '06' },
        { key: '07', label: '07' },
        { key: '08', label: '08' },
        { key: '09', label: '09' },
        { key: '10', label: '10' },
        { key: '11', label: '11' },
        { key: '12', label: '12' },
        { key: '13', label: '13' },
        { key: '14', label: '14' },
        { key: '15', label: '15' },
        { key: '16', label: '16' },
        { key: '17', label: '17' },
        { key: '18', label: '18' },
        { key: '19', label: '19' },
        { key: '20', label: '20' },
        { key: '21', label: '21' },
        { key: '22', label: '22' },
        { key: '23', label: '23' },
        { key: '24', label: '24' },
        { key: '25', label: '25' },
        { key: '26', label: '26' },
        { key: '27', label: '27' },
        { key: '28', label: '28' },
        { key: '29', label: '29' },
        { key: '30', label: '30' },
        { key: '31', label: '31' },
        { key: '32', label: '32' },
        { key: '33', label: '33' },
        { key: '34', label: '34' },
        { key: '35', label: '35' },
        { key: '36', label: '36' },
        { key: '37', label: '37' },
        { key: '38', label: '38' },
        { key: '39', label: '39' },
        { key: '40', label: '40' },
        { key: '41', label: '41' },
        { key: '42', label: '42' },
        { key: '43', label: '43' },
        { key: '44', label: '44' },
        { key: '45', label: '45' },
        { key: '46', label: '46' },
        { key: '47', label: '47' },
        { key: '48', label: '48' },
        { key: '49', label: '49' },
        { key: '50', label: '50' },
        { key: '51', label: '51' },
        { key: '52', label: '52' },
        { key: '53', label: '53' },
        { key: '54', label: '54' },
        { key: '55', label: '55' },
        { key: '56', label: '56' },
        { key: '57', label: '57' },
        { key: '58', label: '58' },
        { key: '59', label: '59' },
        { key: '00', label: '00' }
      ]
    },
    {
      type: 'dropdown',
      name: 'managerName',
      label: 'Manager Name',
      value: 'jack',
      required: true,
      options: [
        { key: 'ram', label: 'Ram' },
        { key: 'shyam', label: 'Shyam' },
        { key: 'jack', label: 'jack' }
      ]
    },
    {
      type: 'text',
      name: 'name1',
      label: 'Name1',
      value: '',
      required: true
    },
    {
      type: 'text',
      name: 'name2',
      label: 'Name2',
      value: '',
      required: true
    },
    {
      type: 'radio',
      name: 'notifyManager',
      label: 'Notify Manager',
      value: 'n',
      required: true,
      options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
    },
    {
      type: 'text',
      name: 'otherDetail',
      label: 'Other Detail',
      value: '',
      required: true
    },
    {
      type: 'text',
      name: 'partofBody',
      label: 'Part of Body',
      value: '',
      required: true
    },
    {
      type: 'text',
      name: 'positionTitle',
      label: 'Position Title',
      value: '',
      required: true
    },
    {
      type: 'radio',
      name: 'returntoWork',
      label: 'Return to Work',
      value: 'n',
      required: true,
      options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
    },
    {
      type: 'dropdown',
      name: 'timeAP',
      label: 'Time AP',
      value: 'am',
      required: true,
      options: [{ key: 'am', label: 'AM' }, { key: 'pm', label: 'PM' }]
    },
    // {
    //   type: 'text',
    //   name: 'treatAmin',
    //   label: 'TreatAmin',
    //   value: '',
    //   required: true
    // },
    {
      type: 'checkbox',
      name: 'treatment',
      label: 'Treatment',
      required: true,
      options: [
        { key: 'treatment1', label: 'Treatment1' },
        { key: 'treatment2', label: 'Treatment2' },
        { key: 'treatment3', label: 'Treatment3' },
        { key: 'treatment4', label: 'Treatment4' },
        { key: 'treatment5', label: 'Treatment5' }
      ]
    },
    // {
    //   type: 'file',
    //   name: 'picture',
    //   label: 'Picture',
    //   required: false,
    //   onUpload: this.onUpload.bind(this)
    // },
    {
      type: 'text',
      name: 'whereIncident',
      label: 'Where Incident',
      value: '',
      required: true
    },
    {
      type: 'radio',
      name: 'witnesses',
      label: 'Witnesses',
      value: 'n',
      required: true,
      options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
    }
  ];

  fieldsHtml = {
    'Brand': {
      html: `<select class="form-control" id="Brand" formControlName="Brand">
   <option value="company1">Company1</option>
   <option value="company2">Company2</option>
   <option value="company3">Company3</option>
   <option value="company4">Company4</option>
 </select>`, field: {
        type: 'dropdown',
        name: 'Brand',
        label: 'Brand',
        value: 'company2',
        required: true,
        options: [
          { key: 'company1', label: 'Company1' },
          { key: 'company2', label: 'Company2' },
          { key: 'company3', label: 'Company3' },
          { key: 'company4', label: 'Company4' }
        ]
      }
    }, 'ContactNumber': {
      html: `<input  attr.type="text" class="form-control"  id="ContactNumber" name="ContactNumber" formControlName="ContactNumber">
`, field: {
        type: 'text',
        name: 'ContactNumber',
        label: 'Contact Number',
        value: '8747737343',
        required: true
      }
    },
    'ContactTel1': {
      html: `<input  attr.type="text" class="form-control"  id="ContactTel1" name="ContactTel1" formControlName="ContactTel1">
`, field: {
        type: 'text',
        name: 'ContactTel1',
        label: 'Contact Tel1',
        value: '',
        required: true
      }
    },
    'ContactTel2': {
      html: `<input attr.type="text" class="form-control"  id="ContactTel2" name="field.name" formControlName="ContactTel2">
`, field: {
        type: 'text',
        name: 'ContactTel2',
        label: 'Contact Tel2',
        value: '',
        required: true
      }
    },
    'DateEntry': {
      html: `<input attr.type="date" class="form-control"  id="DzteEntry" name="DzteEntry" formControlName="DzteEntry">
`, field: {
        type: 'date',
        name: 'DzteEntry',
        label: 'Date Entry',
        value: '2020-02-15',
        required: true
      }
    },
    'Datenotify': {
      html: `<input attr.type="date" class="form-control"  id="Datenotify" name="Datenotify" formControlName="Datenotify">
`, field: {
        type: 'date',
        name: 'Datenotify',
        label: 'Date Notify',
        value: '2020-02-15',
        required: true
      }
    },
    'DescriptionIncident': {
      html: `<input attr.type="text" class="form-control"  id="DescriptionIncident" name="DescriptionIncident" formControlName="DescriptionIncident">
`, field: {
        type: 'text',
        name: 'DescriptionIncident',
        label: 'Description Incident',
        value: '',
        required: true
      }
    },
    'FullName': {
      html: `<input  attr.type="text" class="form-control"  id="FullName" name="FullName" formControlName="FullName">
`, field: {
        type: 'text',
        name: 'FullName',
        label: 'Full Name',
        value: '',
        required: true
      }
    },
    'InjurdTimeHr': {
      html: `<select class="form-control" id="InjurdTimeHr" formControlName="InjurdTimeHr">
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>`, field: {
        type: 'dropdown',
        name: 'InjurdTimeHr',
        label: 'InjurdTimeHr',
        value: '02',
        required: true,
        options: [
          { key: '01', label: '01' },
          { key: '02', label: '02' },
          { key: '03', label: '03' },
          { key: '04', label: '04' },
          { key: '05', label: '05' },
          { key: '06', label: '06' },
          { key: '07', label: '07' },
          { key: '08', label: '08' },
          { key: '09', label: '09' },
          { key: '10', label: '10' },
          { key: '11', label: '11' },
          { key: '12', label: '12' }
        ]
      }
    },
    'InjurdTimeMnt': {
      html: `<select class="form-control" id="InjurdTimeMnt" formControlName="InjurdTimeMnt">
      <option value="01">01</option>
      <option value="02">02</option>
      <option value="03">03</option>
      <option value="04">04</option>
      <option value="05">05</option>
      <option value="06">06</option>
      <option value="07">07</option>
      <option value="08">08</option>
      <option value="09">09</option>
      <option value="10">10</option>
      <option value="11">11</option>
      <option value="12">12</option>
      </select>`, field: {
        type: 'dropdown',
        name: 'InjurdTimeMnt',
        label: 'InjurdTimeMnt',
        value: '25',
        required: true,
        options: [
          { key: '01', label: '01' },
          { key: '02', label: '02' },
          { key: '03', label: '03' },
          { key: '04', label: '04' },
          { key: '05', label: '05' },
          { key: '06', label: '06' },
          { key: '07', label: '07' },
          { key: '08', label: '08' },
          { key: '09', label: '09' },
          { key: '10', label: '10' },
          { key: '11', label: '11' },
          { key: '12', label: '12' },
          { key: '13', label: '13' },
          { key: '14', label: '14' },
          { key: '15', label: '15' },
          { key: '16', label: '16' },
          { key: '17', label: '17' },
          { key: '18', label: '18' },
          { key: '19', label: '19' },
          { key: '20', label: '20' },
          { key: '21', label: '21' },
          { key: '22', label: '22' },
          { key: '23', label: '23' },
          { key: '24', label: '24' },
          { key: '25', label: '25' },
          { key: '26', label: '26' },
          { key: '27', label: '27' },
          { key: '28', label: '28' },
          { key: '29', label: '29' },
          { key: '30', label: '30' },
          { key: '31', label: '31' },
          { key: '32', label: '32' },
          { key: '33', label: '33' },
          { key: '34', label: '34' },
          { key: '35', label: '35' },
          { key: '36', label: '36' },
          { key: '37', label: '37' },
          { key: '38', label: '38' },
          { key: '39', label: '39' },
          { key: '40', label: '40' },
          { key: '41', label: '41' },
          { key: '42', label: '42' },
          { key: '43', label: '43' },
          { key: '44', label: '44' },
          { key: '45', label: '45' },
          { key: '46', label: '46' },
          { key: '47', label: '47' },
          { key: '48', label: '48' },
          { key: '49', label: '49' },
          { key: '50', label: '50' },
          { key: '51', label: '51' },
          { key: '52', label: '52' },
          { key: '53', label: '53' },
          { key: '54', label: '54' },
          { key: '55', label: '55' },
          { key: '56', label: '56' },
          { key: '57', label: '57' },
          { key: '58', label: '58' },
          { key: '59', label: '59' },
          { key: '00', label: '00' }
        ]
      }
    },
    'ManagerName': {
      html: `<select class="form-control" id="ManagerName" formControlName="ManagerName">
      <option value="ram">ram</option>
      <option value="a">a</option>
      <option value="bv">bv</option>
      
      </select>`, field: {
        type: 'dropdown',
        name: 'ManagerName',
        label: 'Manager Name',
        value: 'jack',
        required: true,
        options: [
          { key: 'ram', label: 'Ram' },
          { key: 'shyam', label: 'Shyam' },
          { key: 'jack', label: 'jack' }
        ]
      }
    },
    'Name1': {
      html: `<input  attr.type="text" class="form-control"  id="Name1" name="Name1" formControlName="Name1">
`, field: {
        type: 'text',
        name: 'Name1',
        label: 'Name1',
        value: '',
        required: true
      }
    },
    'Name2': {
      html: `<input  attr.type="text" class="form-control"  id="Name2" name="Name2" formControlName="Name2">
`, field: {
        type: 'text',
        name: 'Name2',
        label: 'Name2',
        value: '',
        required: true
      }
    },
    'NotifyManager': {
      html: `<div class="form-check">
        name: 'NotifyManager',
<input formControlName="NotifyManager" class="form-check-input" type="radio" value="y" >
<label class="form-check-label">
  YES
</label>
<label class="form-check-label">
  NO
</label>
</div>`, field: {
        type: 'radio',
        name: 'NotifyManager',
        label: 'Notify Manager',
        value: 'n',
        required: true,
        options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
      }
    },
    'OtherDetail': {
      html: `<input  attr.type="text" class="form-control"  id="OtherDetail" name="OtherDetail" formControlName="OtherDetail">
`, field: {
        type: 'text',
        name: 'OtherDetail',
        label: 'Other Detail',
        value: '',
        required: true
      }
    },
    'PartofBody': {
      html: `<input  attr.type="text" class="form-control"  id="PartofBody" name="PartofBody" formControlName="PartofBody">
`, field: {
        type: 'text',
        name: 'PartofBody',
        label: 'Part of Body',
        value: '',
        required: true
      }
    },
    'PositionTitle': {
      html: `<input  attr.type="text" class="form-control"  id="PositionTitle" name="PositionTitle" formControlName="PositionTitle">
`, field: {
        type: 'text',
        name: 'PositionTitle',
        label: 'Position Title',
        value: '',
        required: true
      }
    },
    'ReturntoWork': {
      html: `<div class="form-check">
<input formControlName="ReturntoWork" class="form-check-input" type="radio" value="y" >
<label class="form-check-label">
YES
</label>
<label class="form-check-label">
NO
</label>
</div>`, field: {
        type: 'radio',
        name: 'ReturntoWork',
        label: 'Return to Work',
        value: 'n',
        required: true,
        options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
      }
    },
    'TimeAP': {
      html: `<select class="form-control" id="TimeAP" formControlName="TimeAP">
<option value="am">AM</option>
<option value="pm">PM</option>
</select>`, field: {
        type: 'dropdown',
        name: 'TimeAP',
        label: 'Time AP',
        value: 'am',
        required: true,
        options: [{ key: 'am', label: 'AM' }, { key: 'pm', label: 'PM' }]
      }
    },
//     'Treatment': {
//       html: `<div [formGroup]="Treatment" >
// <div class="form-check form-check">
// <label class="form-check-label">
//    <input formControlName="treatment1" class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" />
//    Treatment1</label>
//    <label class="form-check-label">
//    <input formControlName="treatment2" class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2" />
//    Treatment2</label>
//    <label class="form-check-label">
//    <input formControlName="treatment3" class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3" />
//    Treatment3</label>
//    <label class="form-check-label">
//    <input formControlName="treatment4" class="form-check-input" type="checkbox" id="inlineCheckbox4" value="option4" />
//    Treatment4</label>
//    <label class="form-check-label">
//    <input formControlName="treatment5" class="form-check-input" type="checkbox" id="inlineCheckbox5" value="option5" />
//    Treatment5</label>
// </div>
// </div>`, field: {
//         type: 'checkbox',
//         name: 'Treatment',
//         label: 'Treatment',
//         required: true,
//         options: [
//           { key: 'treatment1', label: 'Treatment1' },
//           { key: 'treatment2', label: 'Treatment2' },
//           { key: 'treatment3', label: 'Treatment3' },
//           { key: 'treatment4', label: 'Treatment4' },
//           { key: 'treatment5', label: 'Treatment5' }
//         ]
//       }
//     },
    'WhereIncident': {
      html: `<input  attr.type="text" class="form-control"  id="WhereIncident" name="WhereIncident" formControlName="WhereIncident">
`, field: {
        type: 'text',
        name: 'WhereIncident',
        label: 'Where Incident',
        value: '',
        required: true
      }
    },
    'Witnesses': {
      html: `<div class="form-check">
<input formControlName="Witnesses" class="form-check-input" type="radio" value="n" >
<label class="form-check-label">
  YES
</label>
<label class="form-check-label">
  NO
</label>
</div>`, field: {
        type: 'radio',
        name: 'Witnesses',
        label: 'Witnesses',
        value: 'n',
        required: true,
        options: [{ key: 'y', label: 'Yes' }, { key: 'n', label: 'No' }]
      }
    }

  }


  constructor(@Inject(DomSanitizer) private sanitizer: DomSanitizer,
  private fb:FormBuilder) {
    
  }
  get isValid() { return this.form.valid; }
    get isDirty() { return this.form.dirty; }
  ngOnInit() {
    this.form = new FormGroup({});
    let arr = [];
    let htmldata = `<table class="CSSTableGenerator" style="width: 974px; height: 1342px;">
    <tbody>
        <tr>
            <th style="width: 959.219px;" colspan="4">
                <h2>Register of Injuries, Incident &amp; Hazards</h2><strong style="text-align: justify;"> The purpose
                    of this form is to register a TTC workplace injury, incident, hazard or near<br />miss. This form
                    should be completed as soon as the injury, incident or near miss has<br />occured, or as soon as a
                    hazard is identified. </strong>
            </th>
        </tr>
        <tr>
            <td style="width: 248.141px;">Full Name</td>
            <td style="width: 348.172px;">
  
  <span id="FullName" class="fields" style="background-color: #f1c40f;">&lt;&lt;
                    FullName &gt;&gt;</span>
  
  </td>
            <td style="width: 157.359px;">Contact Number</td>
            <td style="width: 161.281px;">
  <span id="ContactNumber" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; ContactNumber &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 248.938px;">Select Brand</td>
            <td style="width: 348.969px;">
  <span id="Brand" class="fields" style="background-color: #f1c40f;">&lt;&lt;
                    Brand &gt;&gt;</span>
  </td>
            <td style="width: 157.578px;">Position Title</td>
            <td style="width: 161.5px;">
  <span id="PositionTitle" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; PositionTitle &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 249.172px;">Manager's name</td>
            <td style="white-space: nowrap; width: 696.094px;" colspan="4">
  <span id="ManagerName" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; ManagerName &gt;&gt;</span>
  
  </td>
        </tr>
        <tr>
            <td style="width: 249.344px;">Have you notified your manager? Y/N</td>
            <td style="width: 696.016px;" colspan="3">
  <span id="NotifyManager" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; notifyManager &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <th style="width: 959.219px;" colspan="4">
                <h2>Particulars of the Injury, Incident or Hazard</h2>
            </th>
        </tr>
        <tr>
            <td style="width: 249.344px;">Date of Injury</td>
            <td style="width: 349.172px;">
  <span id="DateEntry" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; DateEntry &gt;&gt;</span>
  </td>
            <td style="width: 157.594px;">Time</td>
            <td style="width: 161.656px;">
  <span id="InjurdTimeHr" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; InjurdTimeHr &gt;&gt;</span>
  :
  <span id="InjurdTimeMnt"
                    class="fields" style="background-color: #f1c40f;">&lt;&lt; InjurdTimeMnt &gt;&gt;</span>
  /
  <span id="TimeAP" class="fields" style="background-color: #f1c40f;">&lt;&lt; TimeAP &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 249.344px;">Date Employer Notified</td>
            <td style="width: 696.094px;" colspan="3">
  <span id="Datenotify" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; Datenotify &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 249.344px;">Where did the incident (or hazard) occur?</td>
            <td style="width: 696.094px;" colspan="3">
  <span id="WhereIncident" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; WhereIncident &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 959.219px;" colspan="4">Description of the incident (or hazard) and cause</td>
        </tr>
        <tr>
            <td style="width: 959.219px;" colspan="4">
  <span id="DescriptionIncident" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; DescriptionIncident &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 249.344px;">Were there any witnesses to the incident (or hazard)?</td>
            <td style="width: 696.094px;" colspan="3">
  <span id="Witnesses" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; Witnesses &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 249.344px;">Name</td>
            <td style="width: 349.219px;">
  <span id="Name1" class="fields" style="background-color: #f1c40f;">&lt;&lt;
                    Name1 &gt;&gt;</span>
  </td>
            <td style="width: 157.609px;">Contact telephone</td>
            <td style="width: 161.672px;">
  <span id="ContactTel1" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; ContactTel1 &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 249.344px;">Name</td>
            <td style="width: 349.234px;">
  <span id="Name2" class="fields" style="background-color: #f1c40f;">&lt;&lt;
                    Name2 &gt;&gt;</span>
  </td>
            <td style="width: 157.594px;">Contact telephone</td>
            <td style="width: 161.703px;">
  <span id="ContactTel2" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; ContactTel2 &gt;&gt;</span>
  </td>
        </tr>
        <tr>
            <td style="width: 249.344px;">Part/s of body injured</td>
            <td style="width: 696.094px;" colspan="3">
                <div id="PartofBody" class="ng-binding" draggable="true">PartofBody</div>
            </td>
        </tr>
       
        
        <tr>
            <td style="width: 249.344px;">Did you return to work after treatment?</td>
            <td style="width: 696.094px;" colspan="3">
  <span id="ReturntoWork" class="fields"
                    style="background-color: #f1c40f;">&lt;&lt; ReturntoWork &gt;&gt;</span>
  </td>
        </tr>
    </tbody>
  </table>
  `
  let finalHtml = '';
    this.getStringInBetween(htmldata, '<span', 'span>', arr);
    arr.forEach(element => {
      htmldata = htmldata.replace(element.html,this.fieldsHtml[element.name].html);
      if (this.fieldsHtml[element.name].field.type == 'checkbox') {
        this.form.addControl(this.fieldsHtml[element.name].field.name, new FormGroup({}));
        this.fieldsHtml[element.name].field.options.forEach(o => {
          (this.form.get(this.fieldsHtml[element.name].field.name) as FormGroup).addControl(
            o.key,
            new FormControl(false)
          );
        });
      } else {
        this.form.addControl(
          this.fieldsHtml[element.name].field.name,
          new FormControl(
            this.fieldsHtml[element.name].field.value || '',
            this.fieldsHtml[element.name].field.required ? Validators.required : null
          )
        );
      }
    });
    this.htmlRender = this.sanitizer.bypassSecurityTrustHtml(htmldata);
   // this.htmlRender = this.sanitizer.sanitize(htmldata);
    // let b  = this.htmlData.split('<span');
    // console.log(b);
  }
  ngAfterViewInit(){
    this.unsubcribe = this.form.valueChanges.subscribe(update => {
      console.log(update);
    });
  }
  getStringInBetween(string, start, end, arr) {
    // start and end will be excluded


    let indexOfStart = string.indexOf(start);

    let newString = string.slice(indexOfStart);
    let indexOfEnd = newString.indexOf(end);
    let spanHtml = newString.slice(0, indexOfEnd + end.length);
    let idStrIndex = spanHtml.indexOf('id=');
    let idStr = spanHtml.slice(idStrIndex + 4);
    let indexOfEndId = idStr.indexOf('"');
    let idString = idStr.slice(0, indexOfEndId);
    arr.push({ name: idString, html: spanHtml });
    string = string.replace(spanHtml, '');
    if (string.indexOf('<span') != -1) {
      this.getStringInBetween(string, '<span', 'span>', arr)
    } else {
      return arr;
    }

  }
  saveItem(){
    debugger
    console.log(this.form.value);
  }
}
